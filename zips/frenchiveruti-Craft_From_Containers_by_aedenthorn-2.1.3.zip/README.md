# Craft From Containers by aedenthorn
This is just a reupload for Thunderstore of the mod "Craft Build Smelt Cook Fuel Pull From Containers"

For more information please refer to:  
[Nexus mod page](https://www.nexusmods.com/valheim/mods/40)

## Description

This mod allows you to pull resources from all containers in range when:

- Crafting an item
- Upgrading an item
- Building a construction piece
- Adding fuel or ore to a smelter
- Adding wood to a kiln
- Adding fuel to a fire, standing torch, or sconce,
- Cooking food in a cooking station
- Doing whatever it is you do with windmills


It also provides several **modifier keys** for advanced behaviour:

- A modifier key (**left shift** by *default*) that, when held, pulls until full for ore and fuel.
- A modifier key (**left ctrl** by *default*) that, when held, pulls the resources into the player inventory instead of building/crafting.
- A modifier key to turn off the mod's behaviour entirely (**left alt** by *default*) when held down. This behaviour can also be reversed in the config to only allow this mod to perform its function when the key is held down by setting SwitchPrevent to true.



## Features

Crafting stations and build menu will show an item's creatability based on resources available in all nearby containers rather than just player
inventory.

Resource requirement numbers will now also show the total amount available in nearby chests. You can customize this in the
config file.

Resources that the player's inventory doesn't have enough of will flash yellow (customizable) instead of red.

When building a container, there will now be particle effect lines between the container and crafting stations in range, thanks to bakaspaceman who wrote this code!


## Changelog
#### 2.1.3
- Fix for holding PullItemsKey
#### 2.1.2
- Prevent null exception
#### 2.1.1
- Save container after changing inventory